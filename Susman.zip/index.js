// Tutorial: https://youtu.be/abRY4lbgaF4

const Discord = require("discord.js")
const { Client, Intents } = require('discord.js');

const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });

// when the bot starts up
client.on("ready", () => {
  console.log(`Logged in as ${client.user.tag}!`)
  console.log("Bot is online!")
})

// when someone types a message
client.on("messageCreate", msg => {
  msg.reply("sus");
  if (msg.author == client.user) {
    return;

  } else
    msg.reply("sus")

})

// Add bot token in the "quotes" below
client.login("MTA4MjgzMjI3NjIzODM4MTEyMA.GOcU0l.GE8IeEr2tKvlCAOHorYPprdaIX41Pq2DsUsT2I")


// for uptimerobot:
// https://replname.username.repl.co/